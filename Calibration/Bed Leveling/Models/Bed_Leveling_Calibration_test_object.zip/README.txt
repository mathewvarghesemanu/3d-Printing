                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:13053
Bed Leveling Calibration test object by bsutton is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

This object is designed to help you check that you are correctly leveling you printer bed. It prints three nested squares.
Try to adjust your printer as the object prints (watch out for your fingers :) ). Keep adjusting the bed level until the lines are laid down evenly.

# Instructions

Level your bed, print the object and check the results.

I've uploaded six variations of the stl with different wall heights and widths. 
Depending on your printer/slicer you may need to use one of these variants.

I've also published the original openscad file and I've now publish an onshape CAD document as I've abandoned openscad in favour of onshape.

If one of the standard stl files doesn't suit, then you can adjust the openscad or onshape model directly. Onshape is free to use for us hobbiest and I highly recommend it.

#Onshape changes 
(recommended if one of the default models doesn't work for you)
https://cad.onshape.com/documents/d3f5893072b54cb78782d880/w/e1d290febd8e418db868115d/e/546e2dc0880f43b69ed7e9b0
You will need to be signed up to onshape but if you are doing 3D printing then you should already be signed up :)
To create your own model double click to edit any of the variables (in the left hand side list) then click the 'tick' symbol and your model will update.
To export the model to an STL file, right click the 'tab' labelled 'Bed Calibration Model' (at the bottom of the page) and select export. The select STL as the format.
The onshape variables that you can adjust are:
BedXSize - the dimension of your bed in mm in the X direction.
BedYSize - the dimension of your bed in mm in the Y direction.
LineHeight - the height of each line that is printed. Default 0.3mm
LineWidth - the width of each line that is printed. This should be set to a multiple of you nozzle width. Default: 0.3mm

#OpenScad
You may want to download the scad file and adjust the x, y and z dimensions to match your printer bed.
When in doubt start with the one labelled 'try this one first' (h=0.3, w=0.3)

The default values are:
X_MAX_LENGTH = 173;
Y_MAX_LENGTH = 163;
height = .3;
border_width = 0.2; // This should be slightly less than your extruder width

If your gcodes are empty or simply doesn't print try increasing the height and or the border_width.

This is an updated version of the calibration tool as I've found this version easier to work with.

See the calibration page on reprap.org for full details on calibrating your printer.

http://reprap.org/wiki/Calibration#Bed_Leveling