                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2609816
Adjustable Z axis limit switch mount for TEVO Tarantula by prayalone is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Adjustable Z end stop for Tevo Tarantula.

New to 3d printing. Tevo Tarantula is my first 3D printer.
The green inductive sensor(SN04) failed me as it never detect bed surface at the same spot.
I also fail to adjust the limit switch precisely. After browsing Thingiverse to find some readily available part to print. I found [this](https://www.thingiverse.com/thing:1439423) and [this](https://www.thingiverse.com/thing:1369643) but they require 4 screws and t-nuts to mouth which I don't have. So, I come up with my own design.

- Require only 2 M4 screws and t-nut to mount to the frame (It will not twist as protrusion will fitly engage in frame's slot.
- Adjustable limit switch placement.
- using M3 screw to adjust end stop.

Hope this would help new Tarantula user. :)

# Print Settings

Printer: Tevo Tarantula
Rafts: No
Supports: No
Resolution: 0.2mm
Infill: 25%

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/ff/04/ed/1c/14/IMG_20171027_192846.jpg)